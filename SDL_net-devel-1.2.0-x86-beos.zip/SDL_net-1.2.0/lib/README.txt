Just copy or move the library file to /boot/home/config/lib/ to install.


---------------------
Please distribute this file with the runtime environment:

This library is distributed under the terms of the GNU LGPL license:
http://www.gnu.org/copyleft/lesser.html

